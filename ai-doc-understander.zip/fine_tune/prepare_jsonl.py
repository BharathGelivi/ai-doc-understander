import os, json, glob

IN_DIR = os.environ.get("FINETUNE_IN", "./fine_tune/data")
OUT = os.environ.get("FINETUNE_OUT", "./fine_tune/train.jsonl")

def main():
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as w:
        for fp in glob.glob(os.path.join(IN_DIR, "*.json")):
            with open(fp, "r", encoding="utf-8") as f:
                ex = json.load(f)
            # Expect dict with 'input' and 'output' fields
            w.write(json.dumps({"messages":[
                {"role":"system","content":"You are a helpful contract summarizer."},
                {"role":"user","content": ex["input"]},
                {"role":"assistant","content": json.dumps(ex["output"])}
            ]}, ensure_ascii=False) + "\n")
    print("Wrote", OUT)

if __name__ == "__main__":
    main()
