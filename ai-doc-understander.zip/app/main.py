from fastapi import FastAPI
from .routers import ingest, ner, chat, summarize, translate, asr, tts, topic_anomaly, graph, codegen

app = FastAPI(title="AI Doc Understander", version="0.1.0")

@app.get("/healthz")
def health():
    return {"ok": True}

app.include_router(ingest.router)
app.include_router(ner.router)
app.include_router(chat.router)
app.include_router(summarize.router)
app.include_router(translate.router)
app.include_router(asr.router)
app.include_router(tts.router)
app.include_router(topic_anomaly.router)
app.include_router(graph.router)
app.include_router(codegen.router)
