import uuid
from fastapi import APIRouter, UploadFile, File, Query
from ..schemas import IngestResponse
from ..pipelines.ocr import extract_text_from_pdf
from ..pipelines.rag import upsert_doc
from ..pipelines.summarize import summarize
from ..utils.prompts import load_schema_prompt
from ..settings import settings

router = APIRouter()

# simple in-memory cache of last doc
LAST = {"doc_id": None, "text": None}

@router.post("/ingest", response_model=IngestResponse)
async def ingest(file: UploadFile = File(...), task: str | None = Query(default=None), return_schema: str | None = Query(default=None)):
    content = await file.read()
    text = ""
    num_pages = 0
    if file.filename.lower().endswith(".pdf"):
        text, num_pages = extract_text_from_pdf(content)
    else:
        text = content.decode("utf-8", errors="ignore")
        num_pages = text.count("\n\f") + 1 if text else 1

    doc_id = str(uuid.uuid4())[:8]
    LAST["doc_id"] = doc_id
    LAST["text"] = text

    # Upsert into vector DB (RAG)
    try:
        upsert_doc(doc_id, text)
    except Exception as e:
        print("RAG upsert failed:", e)

    if task == "summarize":
        # structured output if return_schema specified
        summary = summarize(text, return_schema)
        return IngestResponse(doc_id=doc_id, num_pages=num_pages, language=None, text_chars=len(text))
    return IngestResponse(doc_id=doc_id, num_pages=num_pages, language=None, text_chars=len(text))

@router.get("/last_text")
def last_text():
    return {"doc_id": LAST["doc_id"], "text": LAST["text"][:2000] if LAST["text"] else None}
