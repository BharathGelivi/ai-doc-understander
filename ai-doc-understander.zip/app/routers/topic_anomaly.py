from fastapi import APIRouter
from ..schemas import TopicModelRequest, TopicModelResponse, AnomalyRequest, AnomalyResponse
from ..pipelines.topic_model import lda_topics
from ..pipelines.anomaly import anomaly_scores

router = APIRouter()

@router.post("/topic_model", response_model=TopicModelResponse)
def topic_model_endpoint(req: TopicModelRequest):
    topics = lda_topics(req.texts, req.num_topics)
    return {"topics": topics}

@router.post("/anomaly", response_model=AnomalyResponse)
def anomaly_endpoint(req: AnomalyRequest):
    scores = anomaly_scores(req.texts)
    return {"anomalies": scores}
