from fastapi import APIRouter
from ..schemas import GraphBuildRequest, GraphBuildResponse
from ..pipelines.graph import build_graph
from ..settings import settings

router = APIRouter()

@router.post("/graph", response_model=GraphBuildResponse)
def graph_endpoint(req: GraphBuildRequest):
    path, n, e = build_graph(req.text, settings.graph_output_dir)
    return {"graph_path": path, "nodes": n, "edges": e}
