from fastapi import APIRouter
from ..schemas import SummarizeRequest, SummarizeResponse
from ..pipelines.summarize import summarize

router = APIRouter()

@router.post("/summarize", response_model=SummarizeResponse)
def summarize_endpoint(req: SummarizeRequest):
    result = summarize(req.text, req.schema_name)
    return {"summary": result}
