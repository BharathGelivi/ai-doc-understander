from fastapi import APIRouter
from ..schemas import ChatRequest, ChatResponse
from ..pipelines.rag import query
from ..utils.llm import simple_extractive_summary

router = APIRouter()

@router.post("/chat", response_model=ChatResponse)
def chat(req: ChatRequest):
    docs, ids = query(req.query, top_k=5)
    ctx = "\n\n".join(docs)
    # naive, non-LLM baseline answer
    ans = simple_extractive_summary(ctx, max_sentences=5) if ctx else "No relevant context found."
    return ChatResponse(answer=ans, sources=ids)
