import os
from fastapi import APIRouter
from ..schemas import TTSRequest, TTSResponse
from ..settings import settings

router = APIRouter()

@router.post("/tts", response_model=TTSResponse)
def tts_endpoint(req: TTSRequest):
    if settings.tts_provider == "openai" and settings.openai_api_key:
        from openai import OpenAI
        client = OpenAI(api_key=settings.openai_api_key)
        speech_file_path = "/app/data/tts_output.wav"
        with open(speech_file_path, "wb") as f:
            resp = client.audio.speech.with_streaming_response.create(
                model="gpt-4o-mini-tts",
                voice="alloy",
                input=req.text
            )
            resp.stream_to_file(f.name)
        return TTSResponse(audio_path=speech_file_path)
    else:
        # No-op placeholder
        path = "/app/data/tts_placeholder.txt"
        os.makedirs("/app/data", exist_ok=True)
        with open(path, "w", encoding="utf-8") as w:
            w.write("TTS disabled. Configure TTS_PROVIDER=openai and OPENAI_API_KEY to enable.")
        return TTSResponse(audio_path=path)
