from fastapi import APIRouter
from pydantic import BaseModel
from ..settings import settings

router = APIRouter()

class CodeGenReq(BaseModel):
    instruction: str

@router.post("/codegen")
def codegen(req: CodeGenReq):
    """Automated code generation & debugging (provider-agnostic).
    If OpenAI key present, we use it with few-shot examples; else return a helpful stub.
    """
    shots = [
        {"role":"user","content":"Write a Python function to parse clauses starting with 'Section'."},
        {"role":"assistant","content":"def extract_sections(text):\n    import re\n    return re.findall(r"(?m)^Section\s+\d+[^\n]*", text)"}]
    if settings.openai_api_key:
        from openai import OpenAI
        client = OpenAI(api_key=settings.openai_api_key)
        messages = [{"role":"system","content":"You are a precise senior developer."}] + shots + [{"role":"user","content":req.instruction}]
        resp = client.chat.completions.create(model="gpt-4o-mini", messages=messages, temperature=0.2)
        return {"code": resp.choices[0].message.content}
    return {"code": "# Enable OpenAI to get real codegen. For now, write a clear spec and unit tests first."}
