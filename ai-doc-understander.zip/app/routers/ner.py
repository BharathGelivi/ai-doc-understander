from fastapi import APIRouter
from pydantic import BaseModel
from ..schemas import NERResponse
from ..pipelines.ner import run_ner
from .ingest import LAST

router = APIRouter()

class TextReq(BaseModel):
    text: str | None = None

@router.post("/ner", response_model=NERResponse)
def ner_endpoint(req: TextReq):
    text = req.text or (LAST["text"] or "")
    ents = run_ner(text)
    return {"entities": ents}
