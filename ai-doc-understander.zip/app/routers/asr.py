from fastapi import APIRouter, UploadFile, File
from ..pipelines.asr import transcribe_audio

router = APIRouter()

@router.post("/asr")
async def asr_endpoint(file: UploadFile = File(...)):
    fp = f"/tmp/{file.filename}"
    with open(fp, "wb") as w:
        w.write(await file.read())
    text = transcribe_audio(fp)
    return {"text": text}
