from fastapi import APIRouter
from ..schemas import TranslateRequest, TranslateResponse
from ..pipelines.translation import translate

router = APIRouter()

@router.post("/translate", response_model=TranslateResponse)
def translate_endpoint(req: TranslateRequest):
    out = translate(req.text, target_lang=req.target_lang, source_lang=req.source_lang)
    return {"translated_text": out}
