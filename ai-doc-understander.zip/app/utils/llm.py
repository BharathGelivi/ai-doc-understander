import json
from typing import Any, Dict, Optional
from .prompts import load_schema_prompt
from ..settings import settings

try:
    from openai import OpenAI
except Exception:
    OpenAI = None

client = None
if settings.openai_api_key and OpenAI:
    client = OpenAI(api_key=settings.openai_api_key)

def summarize_with_schema(text: str, schema_name: Optional[str]) -> Dict[str, Any]:
    """Structured Output / Controlled Generation.
    If OpenAI key present, use JSON mode; else fallback to a simple extractive baseline
    shaped to the desired schema.
    """
    if schema_name and client:
        schema = load_schema_prompt(schema_name)
        system = "You are a precise contract/policy/paper summarizer. Return ONLY valid JSON."
        messages = [
            {"role":"system","content": system},
            {"role":"user","content": f"""Schema:
{json.dumps(schema['json_schema'], ensure_ascii=False, indent=2)}

Few-shot examples (JSON):
{json.dumps(schema.get('few_shot_examples', []), ensure_ascii=False, indent=2)}

Text:
{text}
Return JSON strictly following the schema."""}
        ]
        resp = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=messages,
            temperature=0.2,
            response_format={"type":"json_object"},
        )
        return json.loads(resp.choices[0].message.content)

    # Fallback: extractive - naive bullets and parties guess
    import re
    bullets = []
    for line in text.splitlines():
        line=line.strip()
        if len(line) > 0 and (line.endswith('.') or len(line) > 60):
            bullets.append(line)
        if len(bullets) >= 7:
            break
    parties = re.findall(r"\b([A-Z][A-Za-z0-9&., ]{2,} (?:Inc|Corp|LLC|Ltd|Company|University))\b", text)
    out = {
        "parties": list(dict.fromkeys(parties))[:5],
        "effective_date": "",
        "term": "",
        "governing_law": "",
        "payment_terms": "",
        "termination": "",
        "obligations": [],
        "key_risks": [],
        "summary_bullets": bullets[:7]
    }
    return out

def simple_extractive_summary(text: str, max_sentences: int = 7) -> str:
    # baseline extractive summary (no LLM)
    import nltk
    nltk.download('punkt', quiet=True)
    from nltk.tokenize import sent_tokenize
    sents = sent_tokenize(text)
    return "\n".join(sents[:max_sentences])
