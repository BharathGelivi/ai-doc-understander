from ..settings import settings

def get_embedder():
    provider = settings.embeddings_provider
    if provider == "openai":
        from openai import OpenAI
        client = OpenAI(api_key=settings.openai_api_key)
        def emb(texts):
            resp = client.embeddings.create(model="text-embedding-3-large", input=texts)
            return [d.embedding for d in resp.data]
        return emb
    elif provider == "sentence-transformers":
        from sentence_transformers import SentenceTransformer
        model = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")
        def emb(texts):
            return model.encode(texts, normalize_embeddings=True).tolist()
        return emb
    else:
        # TF-IDF fallback
        from sklearn.feature_extraction.text import TfidfVectorizer
        vect = TfidfVectorizer(max_features=1024)
        fitted = None
        def emb(texts):
            nonlocal fitted
            if fitted is None:
                fitted = vect.fit(texts)
            return fitted.transform(texts).toarray().tolist()
        return emb
