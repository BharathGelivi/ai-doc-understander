import json, os
from ..settings import settings

def load_schema_prompt(name: str) -> dict:
    path = os.path.join(settings.prompts_dir, f"{name}.json")
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)
