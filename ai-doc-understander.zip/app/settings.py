from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_host: str = "0.0.0.0"
    app_port: int = 8000
    app_env: str = "dev"

    openai_api_key: str | None = None
    tts_provider: str = "none"  # openai, none
    mt_provider: str = "argos"  # argos, openai
    embeddings_provider: str = "sentence-transformers"  # sentence-transformers, openai, tfidf

    anomaly_baseline_dir: str = "./data/baseline_corpus"
    vector_db_dir: str = "./data/chroma"
    graph_output_dir: str = "./data"
    prompts_dir: str = "./prompts"

    asr_enabled: bool = False
    asr_model_size: str = "base"

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8")

settings = Settings()
