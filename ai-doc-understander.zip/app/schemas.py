from pydantic import BaseModel, Field
from typing import List, Optional, Any, Dict

class IngestResponse(BaseModel):
    doc_id: str
    num_pages: int
    language: Optional[str] = None
    text_chars: int | None = None

class NERItem(BaseModel):
    text: str
    label: str
    start: int
    end: int

class NERResponse(BaseModel):
    entities: List[NERItem]

class ChatRequest(BaseModel):
    query: str

class ChatResponse(BaseModel):
    answer: str
    sources: List[str] = []

class SummarizeRequest(BaseModel):
    text: str
    schema_name: Optional[str] = None

class SummarizeResponse(BaseModel):
    summary: Any

class TranslateRequest(BaseModel):
    text: str
    source_lang: Optional[str] = None
    target_lang: str = "en"

class TranslateResponse(BaseModel):
    translated_text: str

class TopicModelRequest(BaseModel):
    texts: List[str]
    num_topics: int = 5

class TopicModelResponse(BaseModel):
    topics: List[Dict[str, Any]]

class AnomalyRequest(BaseModel):
    texts: List[str]

class AnomalyResponse(BaseModel):
    anomalies: List[Dict[str, Any]]

class TTSRequest(BaseModel):
    text: str

class TTSResponse(BaseModel):
    audio_path: str

class GraphBuildRequest(BaseModel):
    text: str

class GraphBuildResponse(BaseModel):
    graph_path: str
    nodes: int
    edges: int
