from ..utils.llm import summarize_with_schema, simple_extractive_summary

def summarize(text: str, schema_name: str | None):
    if schema_name:
        return summarize_with_schema(text, schema_name)
    else:
        return {"summary_bullets": simple_extractive_summary(text).splitlines()}
