import os, re, json, networkx as nx
from typing import Tuple

ORG_RE = re.compile(r"\b([A-Z][A-Za-z0-9&., ]{2,} (?:Inc|Corp|LLC|Ltd|Company|University))\b")
PERSON_RE = re.compile(r"\b([A-Z][a-z]+\s[A-Z][a-z]+)\b")

def build_graph(text: str, out_dir: str = "./data") -> Tuple[str,int,int]:
    G = nx.Graph()
    # naive entities
    orgs = set(ORG_RE.findall(text))
    people = set(PERSON_RE.findall(text))
    for o in orgs:
        G.add_node(o, type="ORG")
    for p in people:
        G.add_node(p, type="PERSON")
    # naive relations: co-occurrence in same sentence
    import nltk
    nltk.download('punkt', quiet=True)
    from nltk.tokenize import sent_tokenize
    for sent in sent_tokenize(text):
        s_orgs = [o for o in orgs if o in sent]
        s_people = [p for p in people if p in sent]
        for o in s_orgs:
            for p in s_people:
                G.add_edge(o, p, relation="mentions")
    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, "graph.graphml")
    nx.write_graphml(G, path)
    # also dump json for quick preview
    with open(os.path.join(out_dir, "graph.json"), "w", encoding="utf-8") as w:
        json.dump(nx.node_link_data(G), w, ensure_ascii=False, indent=2)
    return path, G.number_of_nodes(), G.number_of_edges()
