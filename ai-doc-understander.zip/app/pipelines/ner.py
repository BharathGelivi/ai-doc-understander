import spacy
nlp = spacy.load("en_core_web_sm")

def run_ner(text: str):
    doc = nlp(text)
    return [{"text": ent.text, "label": ent.label_, "start": ent.start_char, "end": ent.end_char} for ent in doc.ents]
