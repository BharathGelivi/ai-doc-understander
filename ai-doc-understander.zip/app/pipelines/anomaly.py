from typing import List, Dict, Any
from sklearn.ensemble import IsolationForest
from ..utils.embeddings import get_embedder

def anomaly_scores(texts: List[str]) -> List[Dict[str, Any]]:
    embed = get_embedder()
    X = embed(texts)
    clf = IsolationForest(random_state=42, contamination="auto")
    clf.fit(X)
    scores = clf.score_samples(X)  # the higher, the less anomalous
    # Convert to anomaly = low score
    out = []
    for i, s in enumerate(scores):
        out.append({"index": i, "score": float(s), "anomaly": s < (sum(scores)/len(scores) - 1.0)})
    return out
