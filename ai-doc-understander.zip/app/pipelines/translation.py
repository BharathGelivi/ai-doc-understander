from ..settings import settings

def translate(text: str, target_lang: str = "en", source_lang: str | None = None) -> str:
    if settings.mt_provider == "openai" and settings.openai_api_key:
        from openai import OpenAI
        client = OpenAI(api_key=settings.openai_api_key)
        messages = [
            {"role":"system","content":"Translate into the target language, keep formatting."},
            {"role":"user","content": f"Target: {target_lang}\nText:\n{text}"}
        ]
        resp = client.chat.completions.create(model="gpt-4o-mini", messages=messages, temperature=0.0)
        return resp.choices[0].message.content.strip()
    else:
        # offline Argos
        import argostranslate.package, argostranslate.translate
        # This is a light wrapper—ensure necessary language packs installed in your runtime
        # For hackathon demo, we attempt even if not installed
        return argostranslate.translate.translate(text, from_code=source_lang or "auto", to_code=target_lang)
