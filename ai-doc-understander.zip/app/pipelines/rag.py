import os, uuid
from typing import List, Tuple
from ..settings import settings
import chromadb
from chromadb.utils import embedding_functions
from ..utils.embeddings import get_embedder

COLLECTION_NAME = "docs"

def get_client():
    os.makedirs(settings.vector_db_dir, exist_ok=True)
    client = chromadb.PersistentClient(path=settings.vector_db_dir)
    return client

def ensure_collection():
    client = get_client()
    coll = client.get_or_create_collection(COLLECTION_NAME)
    return coll

def chunk_text(text: str, chunk_size: int = 1200, overlap: int = 200) -> List[str]:
    chunks = []
    i = 0
    while i < len(text):
        chunks.append(text[i:i+chunk_size])
        i += chunk_size - overlap
    return chunks

def upsert_doc(doc_id: str, text: str) -> int:
    coll = ensure_collection()
    chunks = chunk_text(text)
    embed = get_embedder()
    vectors = embed(chunks)
    ids = [f"{doc_id}_{i}" for i in range(len(chunks))]
    coll.upsert(ids=ids, documents=chunks, embeddings=vectors, metadatas=[{"doc_id":doc_id}] * len(chunks))
    return len(chunks)

def query(query: str, top_k: int = 5) -> Tuple[List[str], List[str]]:
    coll = ensure_collection()
    embed = get_embedder()
    qv = embed([query])[0]
    res = coll.query(query_embeddings=[qv], n_results=top_k)
    docs = res.get("documents", [[]])[0]
    ids = res.get("ids", [[]])[0]
    return docs, ids
