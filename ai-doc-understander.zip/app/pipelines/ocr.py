import io, fitz, pytesseract
from PIL import Image

def extract_text_from_pdf(pdf_bytes: bytes) -> tuple[str, int]:
    """Extract text from text-based and scanned PDFs using PyMuPDF and Tesseract."""
    text_parts = []
    doc = fitz.open(stream=pdf_bytes, filetype="pdf")
    for page in doc:
        # Text layer
        t = page.get_text()
        if t.strip():
            text_parts.append(t)
        else:
            # OCR raster
            pix = page.get_pixmap(dpi=300)
            img = Image.open(io.BytesIO(pix.tobytes("png")))
            t = pytesseract.image_to_string(img)
            text_parts.append(t)
    return "\n".join(text_parts), len(doc)
