from ..settings import settings

def transcribe_audio(path: str) -> str:
    if not settings.asr_enabled:
        raise RuntimeError("ASR is disabled. Set ASR_ENABLED=true in .env")
    from faster_whisper import WhisperModel
    model = WhisperModel(settings.asr_model_size)
    segments, info = model.transcribe(path, beam_size=5)
    return "\n".join([s.text for s in segments])
