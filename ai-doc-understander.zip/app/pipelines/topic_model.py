from typing import List, Dict, Any
from sklearn.decomposition import LatentDirichletAllocation
from sklearn.feature_extraction.text import CountVectorizer

def lda_topics(texts: List[str], num_topics: int = 5) -> List[Dict[str, Any]]:
    vect = CountVectorizer(max_df=0.95, min_df=2, stop_words="english")
    X = vect.fit_transform(texts)
    lda = LatentDirichletAllocation(n_components=num_topics, learning_method="online", random_state=42)
    lda.fit(X)
    topics = []
    terms = vect.get_feature_names_out()
    for idx, comp in enumerate(lda.components_):
        top = comp.argsort()[-10:][::-1]
        topics.append({"topic_id": idx, "top_terms": [terms[i] for i in top]})
    return topics
