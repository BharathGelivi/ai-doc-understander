# AI Doc Understander (Contracts • Policies • Papers)

A containerized FastAPI app that can **ingest**, **understand**, and **summarize** documents (contracts, policies, research papers), leveraging both **Alpha** and **Beta** GenAI techniques.

## Techniques covered

**Alpha**
- **NER** (spaCy)
- **Machine Translation** (provider-agnostic; supports OpenAI or Argos Translate fallback)
- **ASR** (Whisper via `faster-whisper`, optional)
- **TTS** (TTS provider abstraction; optional)
- **Topic Modeling** (scikit-learn LDA)
- **Anomaly Detection** (IsolationForest over sentence embeddings, with TF‑IDF fallback)
- **Automated Code Gen & Debugging** (LLM endpoint with few-shot examples)

**Beta**
- **Structured Output / Controlled Generation** (Pydantic JSON schema + LLM JSON mode)
- **Few-shot Prompting** (prompt templates with examples)
- **Fine-tuning with Domain Data** (data prep scripts; hook points)
- **Document Understanding** (PDF parsing, OCR for scanned pages)
- **Image/Audio Understanding** (OCR for images; ASR for audio)
- **Knowledge Graph Integration** (NetworkX graph exported as GraphML/JSON)

## Quickstart

1. **Clone / unzip** this project.
2. Create a `.env` from the template:
   ```bash
   cp .env.example .env
   # fill in keys as needed (OpenAI optional; Argos-Translate used if offline)
   ```
3. **Build & run** with Docker Compose:
   ```bash
   docker compose up --build
   ```
   App will be served at: http://localhost:8000 — interactive docs at `/docs`.

### Minimal no-keys run
- You can run without any API keys; the app will use local fallbacks:
  - Summarization: classic extractive method
  - NER: spaCy small model
  - Topic modeling: sklearn LDA
  - OCR: Tesseract
  - Embeddings: sentence-transformers if present; else TF‑IDF fallback
  - ASR/TTS: disabled unless you enable/ install optional dependencies

### Example usage (cURL)

**Ingest a PDF and summarize with structured JSON:**
```bash
curl -F "file=@samples/contract_sample.pdf"      -F "task=summarize"      "http://localhost:8000/ingest?return_schema=ContractSummary"
```

**Ask questions (RAG) about the last uploaded doc:**
```bash
curl -X POST "http://localhost:8000/chat" -H "Content-Type: application/json"      -d '{"query":"What are termination clauses and notice period?"}'
```

**Get NER over the extracted text:**
```bash
curl -X POST "http://localhost:8000/ner" -H "Content-Type: application/json"      -d '{"text":"This Agreement between Acme Corp and John Doe effective 1 Jan 2025 ..."}'
```

**Generate audio (TTS) from a summary (if provider enabled):**
```bash
curl -X POST "http://localhost:8000/tts" -H "Content-Type: application/json"      -d '{"text":"Here is your summary."}' --output summary.wav
```

## Services & Modules

- **FastAPI app** with routes in `app/routers/`
- **Pipelines** implementing each technique in `app/pipelines/`
- **RAG** with local Chroma DB (`app/pipelines/rag.py`), persisted in `./data/chroma`
- **Knowledge Graph** (`app/pipelines/graph.py`) exported to `./data/graph.graphml`

## Container images

- Single image (Python 3.11 slim) with:
  - Tesseract + poppler-utils for OCR/PDF support
  - Optional: `faster-whisper` (ASR), `sentence-transformers` for embeddings

> For small cloud VMs (1–2 vCPU, 2–4GB RAM), keep defaults. For heavy workloads, enable GPU variants or external managed APIs.

## Deploy

- **Local**: `docker compose up`
- **Anywhere**: push image to your registry and run behind a reverse proxy (Nginx or cloud run).
- Health check route: `GET /healthz`

## Fine-tuning (hook)

- Put your domain docs (contracts/policies) into `./fine_tune/data/`.
- Run `python fine_tune/prepare_jsonl.py` to create prompt-completion pairs.
- Use your LLM provider’s fine-tune CLI and configure the fine-tuned model name in `.env`.

## License
MIT (for this scaffold). Verify licenses for models/datasets you add.
